This module provide feature of Attendance Management.
