This module provide feature of Timetable.
